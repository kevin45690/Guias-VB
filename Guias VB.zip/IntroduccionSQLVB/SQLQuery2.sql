USE [registroEmpleado]
GO

INSERT INTO [dbo].[empleado]
           ([Nombre]
           ,[Apellido]
           ,[Foto])
     VALUES
           ('kevin'
           ,'figueroa'
           ,'//D')

	select*From empleado
GO

	
