﻿Imports CapaDatos
Imports CapaEntidad
Public Class CNEmpleado

    Dim conexion As New CDEmpleado()

    Public Function ValidadDatos(ByVal empleado As CEEMpleado) As Boolean
        Dim Resultado As Boolean = True

        If empleado.Nombre = "" Then
            Resultado = False
            MessageBox.Show("El campo Nombre es obligatorio", "Mensaje")
        End If

        If empleado.Apellido = "" Then
            Resultado = False
            MessageBox.Show("El campo apellido es obligatorio", "Mensaje")
        End If

        Return Resultado
    End Function




    Public Sub pruebaConexion()
        conexion.prueba()
    End Sub

    Public Function actualizar(ByVal obj As CEEMpleado)
        conexion.update(obj)
    End Function


    Public Function lista() As DataSet
        Return conexion.listar()
    End Function

    Public Sub Insertar(empleado As CEEMpleado)

    End Sub
    Public Function borrar(ByVal obj As Integer)
        If (MessageBox.Show("estas seguro", "pregunta",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question
        )) = DialogResult.Yes Then
            conexion.delete(obj)
        End If
    End Function

End Class



