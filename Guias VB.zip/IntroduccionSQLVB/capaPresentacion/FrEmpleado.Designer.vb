﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrEmpleado
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtNombre = New TextBox()
        txtApellido = New TextBox()
        nudId = New NumericUpDown()
        pcFoto = New PictureBox()
        lnkFoto = New LinkLabel()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        btnNuevo = New Button()
        btnEliminar = New Button()
        btnGuardar = New Button()
        OpenFoto = New OpenFileDialog()
        dgvEmpleado = New DataGridView()
        CType(nudId, ComponentModel.ISupportInitialize).BeginInit()
        CType(pcFoto, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvEmpleado, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtNombre
        ' 
        txtNombre.Location = New Point(552, 72)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(191, 23)
        txtNombre.TabIndex = 0
        ' 
        ' txtApellido
        ' 
        txtApellido.Location = New Point(552, 120)
        txtApellido.Name = "txtApellido"
        txtApellido.Size = New Size(191, 23)
        txtApellido.TabIndex = 1
        ' 
        ' nudId
        ' 
        nudId.Location = New Point(623, 25)
        nudId.Name = "nudId"
        nudId.Size = New Size(120, 23)
        nudId.TabIndex = 2
        ' 
        ' pcFoto
        ' 
        pcFoto.BackColor = Color.Blue
        pcFoto.Location = New Point(12, 12)
        pcFoto.Name = "pcFoto"
        pcFoto.Size = New Size(278, 217)
        pcFoto.SizeMode = PictureBoxSizeMode.StretchImage
        pcFoto.TabIndex = 3
        pcFoto.TabStop = False
        ' 
        ' lnkFoto
        ' 
        lnkFoto.AutoSize = True
        lnkFoto.Location = New Point(124, 243)
        lnkFoto.Name = "lnkFoto"
        lnkFoto.Size = New Size(67, 15)
        lnkFoto.TabIndex = 4
        lnkFoto.TabStop = True
        lnkFoto.Text = "Seleccionar"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(577, 27)
        Label1.Name = "Label1"
        Label1.Size = New Size(17, 15)
        Label1.TabIndex = 5
        Label1.Text = "Id"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(495, 80)
        Label2.Name = "Label2"
        Label2.Size = New Size(51, 15)
        Label2.TabIndex = 6
        Label2.Text = "Nombre"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(495, 128)
        Label3.Name = "Label3"
        Label3.Size = New Size(51, 15)
        Label3.TabIndex = 7
        Label3.Text = "Apellido"
        ' 
        ' btnNuevo
        ' 
        btnNuevo.Location = New Point(368, 23)
        btnNuevo.Name = "btnNuevo"
        btnNuevo.Size = New Size(75, 23)
        btnNuevo.TabIndex = 8
        btnNuevo.Text = "Nuevo"
        btnNuevo.UseVisualStyleBackColor = True
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Location = New Point(368, 71)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(75, 23)
        btnEliminar.TabIndex = 9
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnGuardar
        ' 
        btnGuardar.Location = New Point(368, 128)
        btnGuardar.Name = "btnGuardar"
        btnGuardar.Size = New Size(75, 23)
        btnGuardar.TabIndex = 10
        btnGuardar.Text = "Guardar"
        btnGuardar.UseVisualStyleBackColor = True
        ' 
        ' OpenFoto
        ' 
        OpenFoto.FileName = "OpenFileDialog1"
        ' 
        ' dgvEmpleado
        ' 
        dgvEmpleado.BackgroundColor = SystemColors.ActiveCaption
        dgvEmpleado.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvEmpleado.Location = New Point(313, 169)
        dgvEmpleado.Name = "dgvEmpleado"
        dgvEmpleado.Size = New Size(462, 271)
        dgvEmpleado.TabIndex = 11
        ' 
        ' FrEmpleado
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Yellow
        ClientSize = New Size(787, 445)
        Controls.Add(dgvEmpleado)
        Controls.Add(btnGuardar)
        Controls.Add(btnEliminar)
        Controls.Add(btnNuevo)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(lnkFoto)
        Controls.Add(pcFoto)
        Controls.Add(nudId)
        Controls.Add(txtApellido)
        Controls.Add(txtNombre)
        Name = "FrEmpleado"
        Text = "CRUD VB"
        CType(nudId, ComponentModel.ISupportInitialize).EndInit()
        CType(pcFoto, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvEmpleado, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtApellido As TextBox
    Friend WithEvents nudId As NumericUpDown
    Friend WithEvents pcFoto As PictureBox
    Friend WithEvents lnkFoto As LinkLabel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnNuevo As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnGuardar As Button
    Friend WithEvents OpenFoto As OpenFileDialog
    Friend WithEvents dgvEmpleado As DataGridView

End Class
