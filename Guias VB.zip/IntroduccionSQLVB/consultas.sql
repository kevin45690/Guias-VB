
UPDATE [dbo].[empleado]
   SET [Nombre] = 'josue'
      ,[Apellido] = 'nu�ez'
      ,[Foto] = ''
 WHERE id=1

 SELECT * FROM empleado


