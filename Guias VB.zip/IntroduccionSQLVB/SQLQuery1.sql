

INSERT INTO [dbo].[empleado]
           ([Nombre]
           ,[Apellido]
           ,[Foto])
     VALUES
           ('Kevin'
           ,'Figueroa'
           ,'/DD')

		   Select * From empleado
		   
UPDATE [dbo].[empleado]
   SET [Nombre] = 'Ale'
      ,[Apellido] =' Monge'
      ,[Foto] = ''
 WHERE id = 2
 DELETE FROM [dbo].[empleado]
      WHERE empleado.id = 12
 

