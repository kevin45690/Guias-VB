Imports System

Module Program
    Sub Main()
        Dim contador As Integer = 1

        Do While contador <= 5
            Console.WriteLine(contador)
            contador += 1
        Loop
    End Sub
End Module

