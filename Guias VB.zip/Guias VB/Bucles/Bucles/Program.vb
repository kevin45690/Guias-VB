Imports System

Module Program

    Sub Main()
        Dim i As Integer, suma As Integer
        suma = 0

        For i = 1 To 10
            suma = suma + i
        Next i

        Console.WriteLine("La suma de los primeros 10 n�meros es: " & suma)
    End Sub

End Module

