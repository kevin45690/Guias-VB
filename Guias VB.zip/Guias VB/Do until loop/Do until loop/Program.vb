Imports System

Module Program
    Sub Main()
        Dim numero As Integer = 5

        Do Until numero > 10
            Console.WriteLine("El n�mero es: " & numero)

            numero += 1
        Loop

        Console.WriteLine("N�mero final mayor que 10: " & numero)
    End Sub
End Module
