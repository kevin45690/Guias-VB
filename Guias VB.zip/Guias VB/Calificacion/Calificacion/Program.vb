Imports System

Module Program
    Sub Main()
        ' Solicitar al usuario que ingrese la calificaci�n
        Console.WriteLine("Ingrese la calificaci�n del examen (0-100):")
        Dim calificacion As Integer
        calificacion = Convert.ToInt32(Console.ReadLine())

        ' Verificar si la calificaci�n es Aprobado o Reprobado
        If calificacion >= 60 Then
            Console.WriteLine("Aprobado")
        Else
            Console.WriteLine("Reprobado")
        End If

        ' Pausar la consola para que el usuario pueda ver el resultado
        Console.WriteLine("Presione cualquier tecla para salir...")
        Console.ReadKey()
    End Sub
End Module
