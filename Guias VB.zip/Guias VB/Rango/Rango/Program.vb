Imports System

Module Program
    Sub Main()

        For i As Integer = 1 To 10
            Console.WriteLine(i)
        Next

        Console.WriteLine("Presione cualquier tecla para salir...")
        Console.ReadKey()
    End Sub
End Module
