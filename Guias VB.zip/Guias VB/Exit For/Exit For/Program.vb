Imports System

Module Program
    Sub Main()

        For i As Integer = 1 To 10
            If i = 5 Then
                Exit For
            End If
            Console.WriteLine(i)
        Next


        Console.WriteLine("Presione cualquier tecla para salir...")
        Console.ReadKey()
    End Sub
End Module

