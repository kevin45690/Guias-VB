Imports System

Module Program

    Sub Main()
        Console.Write("Ingrese un n�mero: ")
        Dim num As Integer = Convert.ToInt32(Console.ReadLine())
        If num Mod 2 = 0 Then
            Console.WriteLine("El n�mero es par. ")
        Else
            Console.WriteLine("El n�mero es impar")
        End If
    End Sub
End Module
