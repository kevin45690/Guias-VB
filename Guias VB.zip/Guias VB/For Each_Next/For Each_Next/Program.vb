Imports System

Module Program

    Sub Main()
        RecorrerArregloNombres()
    End Sub

    Sub RecorrerArregloNombres()
        Dim nombres() As String = {"Ana", "Luis", "Pedro", "Marta"}
        Dim nombre As String

        For Each nombre In nombres
            Console.WriteLine("Nombre: " & nombre)
        Next nombre
    End Sub

End Module
