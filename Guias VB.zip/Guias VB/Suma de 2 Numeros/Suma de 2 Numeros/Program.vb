Imports System

Module Program
    Sub Main()
        Console.Write("Ingrese el primer numero: ")
        Dim num1 As Integer = Convert.ToInt32(Console.ReadLine())
        Console.Write("Ingrese el segundo n�mero: ")
        Dim num2 As Integer = Convert.ToInt32(Console.ReadLine())


        Dim suma As Integer = num1 + num2
        Console.WriteLine("La sume es: " & suma)
    End Sub
End Module
