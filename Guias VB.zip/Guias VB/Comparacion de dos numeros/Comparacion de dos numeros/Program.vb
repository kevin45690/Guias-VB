Imports System

Module Program
    Sub Main(args As String())
        Dim num1, num2 As Integer
        num1 = 10
        num2 = 5

        If num1 > num2 Then
            MsgBox("El primer n�mero es mayor")
        ElseIf num1 < num2 Then
            MsgBox("El segundo n�mero es mayor")
        Else
            MsgBox("Ambos n�meros son iguales")
        End If

    End Sub
End Module
