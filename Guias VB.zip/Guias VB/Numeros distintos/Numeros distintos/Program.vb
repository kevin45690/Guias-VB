Imports System

Module Module1
    Sub Main()
        Dim num1, num2 As Integer
        Console.WriteLine("Ingresa el primer n�mero:")
        num1 = Convert.ToInt32(Console.ReadLine())
        Console.WriteLine("Ingresa el segundo n�mero:")
        num2 = Convert.ToInt32(Console.ReadLine())

        If num1 <> num2 Then
            Console.WriteLine("Los n�meros son diferentes")
        End If


        Console.WriteLine("Presiona cualquier tecla para continuar...")
        Console.ReadKey()
    End Sub
End Module

