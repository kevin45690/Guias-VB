Imports System

Module Program
    Sub Main()

        Console.WriteLine("Ingrese un n�mero:")
        Dim num As Integer
        num = Convert.ToInt32(Console.ReadLine())


        If num > 0 Then
            Console.WriteLine("El n�mero es positivo")
        ElseIf num < 0 Then
            Console.WriteLine("El n�mero es negativo")
        Else
            Console.WriteLine("El n�mero es cero")
        End If


        Console.WriteLine("Presione cualquier tecla para salir...")
        Console.ReadKey()
    End Sub
End Module
