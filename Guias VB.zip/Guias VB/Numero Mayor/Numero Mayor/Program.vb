Imports System

Module Module1
    Sub Main()
        Dim edad As Integer
        Console.WriteLine("Ingresa tu edad:")
        edad = Convert.ToInt32(Console.ReadLine())

        If edad >= 18 Then
            Console.WriteLine("Eres mayor de edad")
        Else
            Console.WriteLine("Eres menor de edad")
        End If


        Console.WriteLine("Presiona cualquier tecla para continuar...")
        Console.ReadKey()
    End Sub
End Module

