Imports System

Module Module1
    Sub Main()
        Dim dia As Integer
        Console.WriteLine("Ingresa un n�mero entre 1 y 7:")
        dia = Convert.ToInt32(Console.ReadLine())

        Select Case dia
            Case 1
                Console.WriteLine("Lunes")
            Case 2
                Console.WriteLine("Martes")
            Case 3
                Console.WriteLine("Mi�rcoles")
            Case 4
                Console.WriteLine("Jueves")
            Case 5
                Console.WriteLine("Viernes")
            Case 6
                Console.WriteLine("S�bado")
            Case 7
                Console.WriteLine("Domingo")
            Case Else
                Console.WriteLine("N�mero inv�lido")
        End Select


        Console.WriteLine("Presiona cualquier tecla para continuar...")
        Console.ReadKey()
    End Sub
End Module
