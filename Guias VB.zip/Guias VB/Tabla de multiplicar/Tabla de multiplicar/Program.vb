Imports System

Module Program
    Sub Main()
        Console.Write("Ingrese un n�mero: ")
        Dim num As Integer = Convert.ToInt32(Console.ReadLine())

        For i As Integer = 1 To 10
            Console.WriteLine(num & " x " & i & " = " & (num * i))
        Next
    End Sub
End Module
