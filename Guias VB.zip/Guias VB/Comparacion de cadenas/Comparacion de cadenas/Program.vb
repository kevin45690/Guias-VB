Imports System

Module Module1
    Sub Main()
        Dim texto1, texto2 As String
        Console.WriteLine("Ingresa la primera cadena de texto:")
        texto1 = Console.ReadLine()
        Console.WriteLine("Ingresa la segunda cadena de texto:")
        texto2 = Console.ReadLine()

        If texto1 = texto2 Then
            Console.WriteLine("Las cadenas son iguales")
        Else
            Console.WriteLine("Las cadenas son diferentes")
        End If


        Console.WriteLine("Presiona cualquier tecla para continuar...")
        Console.ReadKey()
    End Sub
End Module

